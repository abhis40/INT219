$("#signup-valid").validate({
    rules: {
        name: {
            minlength: 0
        },
        email: {
            email: true
        },
        password: {
            minlength: 5,
            maxlength: 16
        },
        signupCheck: {
            signupCheck: true
        }
    },
    messages: {
        name: {
            required: "Please Enter Your Name",
            minlength: "Name at Least have 5 Characters"
        },
        email: "Please Enter your Email",
        password: "Password must be between 5 and 16 characters",

    },

    submitHandler: function(form) {
        form.submit();
    }
});
$("#signup-btn").click(function() {
    var name = $("#name").val();
    var email = $("#email").val();
    var password = $("#password").val();

    if (name.length < 5) {
        alert("Invalid Name")
        return;
    }

    if (email.indexOf("@") < 0 || email.indexOf(".") < 0) {
        alert("Invalid Email")
        return;
    }

    if (!(password.length >= 5 && password.length <= 16)) {
        alert("Password must be between 5 and 16 characters")
        return;
    }

});


$("#login-valid").validate({
    rules: {
        Email: {
            Email: true
        },
        Password: {
            minlength: 5,
            maxlength: 16
        }
    },
    messages: {
        Email: "Please Enter your Email",
        Password: "Please Enter the Password"
    },

    submitHandler: function(form) {
        form.submit();
    }
});
$(function() {
    $("#login-btn").click(function() {
        var Email = $("#Email").val();
        var Password = $("#Password").val();

        if (Email.indexOf("@") < 0 || Email.indexOf(".") < 0) {
            alert("Invalid Email")
            return;
        }

        if (!(Password.length >= 5 && Password.length <= 16)) {
            alert("Password must be between 5 and 16 characters")
            return;
        }
        window.open("index.html");
    });

});